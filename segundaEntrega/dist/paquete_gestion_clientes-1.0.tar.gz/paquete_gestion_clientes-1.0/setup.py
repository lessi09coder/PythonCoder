from setuptools import setup

setup(
    name="paquete_gestion_clientes",
    version="1.0",
    description="Gestion de clientes para una tienda online.",
    author="Alexis Bonetti",
    author_email= "algunEmail@gmail.com",

    packages= ["paquete_primera_entrega"]
)